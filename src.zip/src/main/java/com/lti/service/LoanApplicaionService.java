package com.lti.service;

import com.lti.dto.LoanApplicationDto;

public interface LoanApplicaionService {

	public String addLoanApplication(LoanApplicationDto loanApplicationDto);
}
