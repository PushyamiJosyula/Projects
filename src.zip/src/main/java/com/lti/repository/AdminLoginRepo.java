package com.lti.repository;

import com.lti.entity.AdminLogin;

public interface AdminLoginRepo {

	public AdminLogin loginAdmin(String adminId);
}
