import { TestBed } from '@angular/core/testing';

import { ExamUserService } from './exam-user.service';

describe('ExamUserService', () => {
  let service: ExamUserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ExamUserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
