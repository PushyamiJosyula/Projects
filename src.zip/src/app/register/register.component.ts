import { Component, OnInit } from '@angular/core';

import { ExamUser } from './ExamUser';
import { RegisterService } from './register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private regServ: RegisterService) { }
  examuser: ExamUser = new ExamUser();
  ngOnInit(): void {
  }
  addUser(examuser: ExamUser){
    this.regServ.addUserService(examuser).subscribe((data)=>
    {
     
      if(data!=null){
        alert(this.examuser);
        console.log(data);
        alert(data);
        alert("registration successful");
      }},
      (err)=>{
        alert("some thing went wrong");
       console.log(err);
     }
    
    )
  }
}
