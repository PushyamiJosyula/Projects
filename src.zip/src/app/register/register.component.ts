import { Component, OnInit } from '@angular/core';
import { ExamUserService } from './exam-user.service';
import { ExamUser } from './ExamUser';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private user: ExamUserService) { }
  examuser: ExamUser = new ExamUser();
  ngOnInit(): void {
  }
  addUser(examuser: ExamUser){
    this.user.addUserService(examuser).subscribe((data)=>
    {
     
      if(data!=null){
        alert(this.examuser);
        console.log(data);
        alert(data);
        alert("registration successful");
      }},
      (err)=>{
        alert("some thing went wrong");
       console.log(err);
     }
    
    )
  }
}
