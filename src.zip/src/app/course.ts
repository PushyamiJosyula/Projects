export class Course{
    id: number | undefined 
    name: string | undefined ;  
}