export class QuestionDTO{

    public qsNo: number | undefined;
   
   crctOpt: string|undefined;

    opta: string|undefined;

    optb: string|undefined;

    optc: string|undefined;

    optd: string|undefined;
   
    examId: number|undefined;
    levelId: number|undefined;

    question: string|undefined;
}