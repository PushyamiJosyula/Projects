export class Question{
    
    public questionId!: number;

    public qsNo!: number;
   
    public crctOpt!: String;

    public opta!: string;

    public optb!: string;

    public optc!: string;

    public optd!: string;
   
    public examId!: number;
    public levelId!: number;

    public question!: string;
}