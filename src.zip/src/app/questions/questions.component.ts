import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { QuestionService } from './question.service';
import { QuestionDTO } from './QuestionDTO';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {

  constructor(private question: QuestionService){ }
  questDto: QuestionDTO = new QuestionDTO();
  
  ngOnInit(): void {
  }
  ExamId=0;
  LevelId=0;
  tempQuestion: Array<any> | undefined;
  findQuestionsByExamIdLevelId(ExamId: number,LevelId:number){
    //alert("I am Called");
    this.question.findQuestionsByExamIdLevelIdService(ExamId,LevelId).subscribe((data)=>{
      if(data!=null){
        this.tempQuestion=data;
       // alert(this.tempQuestion);
      }
      else{
        alert("unable to fetch data");
      }
    })
  }
  
  // quest: QuestionDTO = new QuestionDTO();
  
  // questionForm = new FormGroup({
  //   this.quest.qsNo: new FormControl('', Validators.required)
  // });
  // i: number | undefined;
  // onOptionSubmit(){
  //   var ele = document.getElementsByName('quest.qsNo');
    
  //   for(this.i=0;this.i<ele.length;this.i++){
  //    if(ele[this.i].checked)
  //    alert(ele[this.i].nodeValue);
  //   }
    
   // alert(this.questionForm.get('quest.qsNo'));
    
    
  }

