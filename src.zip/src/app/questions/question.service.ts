import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { QuestionDTO } from './QuestionDTO';

@Injectable({
  providedIn: 'root'
})
export class QuestionService {

  constructor(private myHttp:HttpClient) { }


findQuestionsByExamIdLevelIdService(ExamId: number,LevelId:number):Observable<any>{
  return this.myHttp.get<QuestionDTO>("http://localhost:8080/getQuestion/"+ExamId+"/"+LevelId);
  }
}