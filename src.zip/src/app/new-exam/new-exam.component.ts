import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-new-exam',
  templateUrl: './new-exam.component.html',
  styleUrls: ['./new-exam.component.css']
})
export class NewExamComponent implements OnInit {
  title = "Card View Demo";

  gridColumns = 4;

  cardData: {
    title: string;
    description: string;
    imageUrl: SafeResourceUrl;
  }[] = [];
   
  constructor() {
    this.initData();
  }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  initData(): void {
    this.cardData = [
    {
      title: "c++",
      description: "c++ test",
      imageUrl: (
        "/assets/img/cplus.png"
      )
    },
    {
      title: ".Net",
      description:
        ".Net exam test ",
      imageUrl:("/assets/img/large.png")
    },
    {
      title: "SQL",
      description: "Sql exam",
      imageUrl:("/assets/img/sql.png")
    },
    {
      title: "PHP",
      description:
        "This  is simple php exam",
      imageUrl:("/assets/img/php.png")
    },
    {
      title: "Java",
      description: "Level: 1",
      imageUrl:("/assets/img/java.png")
    },
    
    
  ];
  }

  toggleGridColumns() {
    this.gridColumns = this.gridColumns === 3 ? 4 : 3;
  }

}
