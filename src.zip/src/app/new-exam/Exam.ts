export class Exam{
    examId!: number;
    examName!:string;
    examDate!:Date;
    imageUrl!:string;

}